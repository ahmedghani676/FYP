# Autonomous-Large-Scale-Facial-Recognition-Automated-Attendance-System

It is a software project that automates the process of taking attendance using facial recognition technology. It likely includes the source code, documentation, and other resources necessary to build and run the attendance system.
